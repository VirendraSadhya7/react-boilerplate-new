const App = () => {
  return (
    <div className="mt-5 w-[80%] m-auto">
      <h1 className="text-8xl">This is React  Boileapate</h1>
      <h2 className="text-4xl">{import.meta.env.VITE_API_KEY}</h2>
      <button className="px-8 py-4 bg-blue-300 rounded ">Explore</button>
    </div>
  );
};

export default App;
